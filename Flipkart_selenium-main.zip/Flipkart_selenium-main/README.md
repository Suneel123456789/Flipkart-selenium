<dependencies>
	<dependency>
	    <groupId>org.seleniumhq.selenium</groupId>
	    <artifactId>selenium-java</artifactId>
	    <version>4.16.1</version>
	</dependency>
</dependencies>
